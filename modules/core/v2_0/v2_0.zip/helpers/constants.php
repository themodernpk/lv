<?php

/* ****** Code Completed till 10th april */
/* #################################
 * These are constants defined
 * #################################
 */
define('core_app_name', 'LV App');
define('core_app_full_name', 'LV App Framework');
define('core_app_licensed', 'Application is licensed to <b>WebReinvent</b>');
define('core_nav_header', 'Navigation');
define('core_success_message', "Success! It's done");
define('core_failed_undefined', 'Undefined Error');
define('core_success', "Success! It's done");
define('core_failed_not_exist', "Data does not exist");
define('core_msg_exceptions', "This data under exception, action can't be performed");
define('core_msg_permission_denied', "Permission Denied.");
define('core_no_item_selected', "No item is selected");

/* ******\ Code Completed till 10th april */
