<!--modal-->
{{HtmlHelper::modal(array('title' => "Details are following", 'modal_id'=>"ModalView"))}}

<!--modal body-->
<div class="modal-body">
    <div class="row">
    </div>
</div>
<!--/modal body-->
<div class="modal-footer">
    <a href="#" data-dismiss="modal" class="btn btn-sm btn-white" >Close</a>
</div>
{{HtmlHelper::modalClose()}}
<!--/modal-->
